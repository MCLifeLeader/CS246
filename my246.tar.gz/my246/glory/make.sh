javac -cp /home/car03009/my246/glory/org/jdesktop/layout/*.class:. Glory.java
