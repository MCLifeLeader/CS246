1 License
GNU General Public License.

2 Code
The code is badly documented and will be reworked some day. 

3 Short Structure Overview
The following design patterns are used in the code:
- Several Singleton patterns are responsible for selection and command execution aspects;
- The Command pattern implements undo/redo;
- The Prototype pattern handles UML element creation.

4 Custom UML Elements
Please refer to the FAQ on the UMLet Web site.

Hava fun!
The UMLet Team
info@umlet.com
www.umlet.com
