public class TestTimestampingFileToucher
{
   public static void main( String [] args )
   {
      new TimestampingFileToucher(args).run();
   }
}
