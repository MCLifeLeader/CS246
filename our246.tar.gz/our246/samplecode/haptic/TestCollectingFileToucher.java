/**
 * A simple test for the CollectingFileToucher
 */
public class TestCollectingFileToucher
{
   public static void main(String[] args)
   {
       new CollectingFileToucher(args).run();
   }
}
