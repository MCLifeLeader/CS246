public class Particle
{
   public String toString()
   {
      return getClass().getName();
   }
}
