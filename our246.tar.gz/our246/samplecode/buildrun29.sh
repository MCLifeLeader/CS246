#!/bin/sh

javac -cp /home/cs246/samplecode/haptic:../util:. Question29.java
java -cp /home/cs246/samplecode/haptic:../util:. Question29 JavaCountingFileToucher TxtFileCollectorInNotes alskdjf
